import React from "react";
import "./contact.css";

const Contact = () => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "row",
        justifyContent: "space-between",
      }}
    >
      <div className="left">
        <div className="con-1">
          <h2 style={{ color: "red" }}>Locations</h2>
          <div className="con-1_1">
            <div>
              <h3 style={{ color: "red" }}>
                {" "}
                <p>
                  United Arab Emirates <br />
                  Prance General Trading LLC
                </p>
              </h3>
              <p>
                6th Floor, <br />
                AlAbisar Business Centre, <br />
                Bayan Business Centre, <br />
                Dubai Investment Park, Dubai, <br />
                United Arab Emirates.
              </p>
            </div>
            <div style={{ marginLeft: 3 }}>
              <h3 style={{ color: "red" }}>
                <p>
                  India <br />
                  Prance Industries Pvt. Ltd.
                </p>
              </h3>
              <p>
                Seat No 10B/706 <br />
                32, Chowringhee Road Om <br />
                Tower Park Street, Kolkata, <br />
                West Bengal, 700071
              </p>
            </div>
          </div>
        </div>

        <div className="con-2">
          <p>Email: info@pranceventure.com</p>
        </div>

        <div className="con-3" style={{ marginTop: 1 }}>
          <p>Phone:- +971507293911</p>
        </div>

        <div className="con-4">
          <div style={{ color: "red" }}>
            Click or scan to connnect on <br /> Whatsapp
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
