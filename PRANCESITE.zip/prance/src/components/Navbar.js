import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  return (
    <div>
      <nav className="navbar bg-body-tertiary">
        <div className="container-fluid">
          <img
            style={{ height: 60, width: 60, borderRadius: 50 }}
            src={require("./logo.png")}
            alt={"..."}
          />
          <button className="btn btn-danger">
            <Link className="nav-link" to="/">
              Home
            </Link>
          </button>
          <button style={{ marginRight: 400 }} className="btn btn-danger">
            <Link className="nav-link" to="/contact">
              ContactUs
            </Link>
          </button>
        </div>
      </nav>
    </div>
  );
};

export default Navbar;
