import React from "react";
import Slides from "./Slides.js";
import Product from "./Products/Product.js";

const Home = () => {
  return (
    <div>
      <Slides />
      <Product />
    </div>
  );
};

export default Home;
